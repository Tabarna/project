package com.springboot.management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import javax.persistence.*;
import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity @Table(name="emp")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //	By @GeneratedValue, JPA makes a unique key automatically and applies the key to the field having @Id
    private int id;
   // @DateTimeFormat(pattern="yyyy-MM-dd")
   // LocalDate dob;
    private int employee_Id;
    private String first_Name;
    private String last_Name;
    private String email_Id;
    //private int Project_ID;
  //  @JoinColumn(name = "Project_name")
  //  private  String Project;
//    private  int employee_id;
//    private String Skill;



}
