package com.springboot.management.controller;

import com.springboot.management.entity.Project;
import com.springboot.management.entity.Skill;
import com.springboot.management.service.ProjectService;
import com.springboot.management.service.SkillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class SkillController {


    @Autowired
    private SkillService skillservice;


    @PostMapping("/addSkill")
    public Skill addSkill(@RequestBody Skill skill){
        return skillservice.savedata(skill);
    }
    @PostMapping("/addSkills")
    public List<Skill> addSkills(@RequestBody List<Skill> skill){
        return skillservice.savedatas(skill);
    }
    @GetMapping("/Skills")
    public List<Skill>findAllDatas(){
        return skillservice.getSkills();
    }
    @GetMapping("/Skills/{id}")
    public Skill findSkillsById(@PathVariable int id){
        return skillservice.getSkillById(id);
    }

    //    @GetMapping("/Skills/{name}")
//    public Project findSkillsByName(@PathVariable String Name){
//        return skillservice.getSkillsbyName(project_Name);
//    }

    @DeleteMapping("/deleteskill/{id}")
    public String deleteSkills(@PathVariable int id){
        return skillservice.deleteSkills(id);
    }

}
