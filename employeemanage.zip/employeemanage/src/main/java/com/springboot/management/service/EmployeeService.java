package com.springboot.management.service;

import com.springboot.management.entity.Employee;
import com.springboot.management.repository.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class EmployeeService {


    @Autowired
    private Repository repository;

    public Employee savedata(Employee employee){
        return   repository.save(employee);
    }

    public List<Employee> savedatas(List<Employee> employees){
        return (List<Employee>) repository.saveAll(employees);
    }

    public List<Employee> getEmployees(){
        return (List<Employee>) repository.findAll();
    }


    public Employee getEmployeesById(int id){
        return repository.findById(id).orElse(null);
    }
    public String deleteEmloyees(int id){
        repository.deleteById(id);
        return "data deleted" +id;
    }
    public  Employee updateEmployees(Employee employee){
        Employee existingEmployee=repository.findById(employee.getId()).orElse(null);
        existingEmployee.setFirst_Name(employee.getFirst_Name());
        existingEmployee.setLast_Name(employee.getLast_Name());

        existingEmployee.setEmail_Id(employee.getEmail_Id());
//        existingEmployee.setProject_ID(employee.getProject_ID());
//        existingEmployee.setProject(employee.getProject());
        existingEmployee.setEmployee_Id(employee.getEmployee_Id());
//        existingEmployee.setSkill(employee.getSkill());
        return  repository.save(existingEmployee);
    }


}
