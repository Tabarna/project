package com.springboot.management.controller;



import com.springboot.management.entity.Employee;
import com.springboot.management.repository.Repository;
import com.springboot.management.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController

public class EmployeeController {



    @Autowired
    private EmployeeService service;


    @PostMapping("/addData")
    public Employee addData(@RequestBody Employee employee){
        return service.savedata(employee);
    }
    @PostMapping("/addDatas")
    public List<Employee> addDatas(@RequestBody List<Employee> employees){
        return service.savedatas(employees);
    }
    @GetMapping("/Employee")
    public List<Employee>findAllDatas(){
        return service.getEmployees();
    }
    @GetMapping("/Employee/{id}")
    public Employee findEmployeeById(@PathVariable int id){
        return service.getEmployeesById(id);
    }
    @PutMapping("/update")
    public Employee updateEmployees(@RequestBody Employee employee)
    {
        return service.updateEmployees(employee);
    }
    @DeleteMapping("/delete/{id}")
    public String deleteEmployees(@PathVariable int id){
        return service.deleteEmloyees(id);
    }
//    @GetMapping("/Employee/{skill}")
//    public Employee findEmployeeBySkill(@PathVariable String skill){
//        return service.getEmployeesBySkill(skill);
//    }skill
//    @GetMapping("/Employee/{employee_id}")
//    public Employee findEmployeeByEmployeeId(@PathVariable int employee_id){
//        return service.getEmployeesByEmployeeId(employee_id);
//    }
//    @GetMapping("/Employee/{emailid}")
//    public Employee findEmployeeByEmailId(@PathVariable String emailid){
//        return service.getEmployeesByEmailId(emailid);
//    }
//
//    @GetMapping("/Employee/{id}/{skill}")
//    public Employee findEmployeeByIdAndskill(@PathVariable int id, String skill){
//        return service.getEmployeesByIdAndskill(id,skill);
//    }

}
