package com.springboot.management.service;

import com.springboot.management.entity.Project;
import com.springboot.management.entity.Skill;
import com.springboot.management.repository.ProjectRepository;
import com.springboot.management.repository.SkillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillService {


    @Autowired
    private static SkillRepository repository;


    public Skill savedata(Skill skill){
        return   repository.save(skill);
    }

    public List<Skill> savedatas(List<Skill> skills){
        return (List<Skill>) repository.saveAll(skills);
    }

    public List<Skill> getSkills(){
        return (List<Skill>) repository.findAll();
    }

    public Skill getSkillById(int skillid){
        return repository.findById(skillid).orElse(null);
    }

    public String deleteSkills(int skillid){
        repository.deleteById(skillid);
        return "Project Data Deleted....." + skillid;
    }

}
