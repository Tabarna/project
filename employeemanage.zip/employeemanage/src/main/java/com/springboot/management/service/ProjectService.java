package com.springboot.management.service;

import com.springboot.management.entity.Employee;
import com.springboot.management.entity.Project;
import com.springboot.management.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
@Service
public class ProjectService {

//

    @Autowired
    private ProjectRepository repository;




    public Project savedata(Project project){
        return   repository.save(project);
    }

    public List<Project> savedatas(List<Project> projects){
        return (List<Project>) repository.saveAll(projects);
    }

    public List<Project> getProjects(){
        return (List<Project>) repository.findAll();
    }

    public Project getProjectById(int Project_Id){
        return repository.findById(Project_Id).orElse(null);
    }
//    public Project getProjectByproject_Name(String project_Name){
//        return  projectRepository.findByproject_Name(project_Name);
//    }

    public String deleteProjects(int Project_Id){
        repository.deleteById(Project_Id);
        return "Project Data Deleted....." + Project_Id;
    }




    public  Project updateProjects(Project project){
        Project existingProject=repository.findById(project.getProject_id()).orElse(null);
        existingProject.setProject_Name(project.getProject_Name());
        existingProject.setSkill_Name(project.getSkill_Name());
        existingProject.setProject_id(project.getProject_id());


        return  repository.save(existingProject);
    }

}
