package com.springboot.management.controller;

import com.springboot.management.entity.Employee;
import com.springboot.management.entity.Project;
import com.springboot.management.repository.ProjectRepository;
import com.springboot.management.service.EmployeeService;
import com.springboot.management.service.ProjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ProjectController {


    @Autowired
   private ProjectService projectservice;


    @PostMapping("/addProject")
    public Project addProject(@RequestBody Project project){
        return projectservice.savedata(project);
    }
    @PostMapping("/addProjects")
    public List<Project> addProjeccts(@RequestBody List<Project> projects){
        return projectservice.savedatas(projects);
    }
    @GetMapping("/Projects")
    public List<Project>findAllDatas(){
        return projectservice.getProjects();
    }
    @GetMapping("/Projects/{id}")
    public Project findProjectsById(@PathVariable int id){
        return projectservice.getProjectById(id);
    }

    //    @GetMapping("/Projects/{name}")
//    public Project findProjectsByproject_Name(@PathVariable String project_Name){
//        return projectservice.getProjectByproject_Name(project_Name);
//    }


    @PutMapping("/updatedata")
    public Project updateProjects(@RequestBody Project project)
    {
        return projectservice.updateProjects(project);
    }
    @DeleteMapping("/deletedata/{id}")
    public String deleteProjects(@PathVariable int id){
        return projectservice.deleteProjects(id);
    }
}
