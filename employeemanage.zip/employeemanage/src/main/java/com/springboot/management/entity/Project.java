package com.springboot.management.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="projectdata")
public class Project {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //	By @GeneratedValue, JPA makes a unique key automatically and applies the key to the field having @Id
    private int Project_id;
    private String project_Name;
    private String skill_Name;
    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "cId", referencedColumnName = "Project_Id")
    //private int Project_Id;
    private List<Employee> employeeList;
}
