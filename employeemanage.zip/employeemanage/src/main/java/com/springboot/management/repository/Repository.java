package com.springboot.management.repository;

import com.springboot.management.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;
@org.springframework.stereotype.Repository
public interface Repository extends JpaRepository<Employee,Integer> {

}
